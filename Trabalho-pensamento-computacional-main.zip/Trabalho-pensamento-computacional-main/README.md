# Trabalho-pensamento-computacional
Trabalho
